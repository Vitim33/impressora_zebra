import React from 'react';
import BaseScreen from '../components/BaseScreen';

const AlimentacaoScreen: React.FC = () => {
  return <BaseScreen title="Alimentação" />;
};

export default AlimentacaoScreen;
