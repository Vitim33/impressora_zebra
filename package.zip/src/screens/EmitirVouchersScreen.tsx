import React from 'react';
import BaseScreen from '../components/BaseScreen';

const EmitirVouchersScreen: React.FC = () => {
  return <BaseScreen title="Emitir Vouchers" />;
};

export default EmitirVouchersScreen;
