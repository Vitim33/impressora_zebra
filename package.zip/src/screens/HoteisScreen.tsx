import React from 'react';
import BaseScreen from '../components/BaseScreen';

const HoteisScreen: React.FC = () => {
  return <BaseScreen title="Hotéis" />;
};

export default HoteisScreen;
