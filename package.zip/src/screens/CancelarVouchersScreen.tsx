import React from 'react';
import BaseScreen from '../components/BaseScreen';

const CancelarVouchersScreen: React.FC = () => {
  return <BaseScreen title="Cancelar Vouchers" />;
};

export default CancelarVouchersScreen;
