import React from 'react';
import BaseScreen from '../components/BaseScreen';

const AutorizacaoVouchersScreen: React.FC = () => {
  return <BaseScreen title="Autorização de Vouchers" />;
};

export default AutorizacaoVouchersScreen;
