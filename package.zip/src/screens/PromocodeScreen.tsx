import React from 'react';
import BaseScreen from '../components/BaseScreen';

const PromocodeScreen: React.FC = () => {
  return <BaseScreen title="Promocode" />;
};

export default PromocodeScreen;
