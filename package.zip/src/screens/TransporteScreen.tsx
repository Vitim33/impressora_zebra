import React from 'react';
import BaseScreen from '../components/BaseScreen';

const TransporteScreen: React.FC = () => {
  return <BaseScreen title="Transporte" />;
};

export default TransporteScreen;
